package ch.get.view;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

public class BackGroundController implements Initializable{

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
}
