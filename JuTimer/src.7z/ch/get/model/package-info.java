/**
 * 
 */
/**
 * @author Get
 *
 */
package ch.get.model;