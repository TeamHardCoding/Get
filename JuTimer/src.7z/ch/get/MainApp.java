package ch.get;

import ch.get.view.RootLayoutController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainApp extends Application {

	private Stage primaryStage; //���� stage
	
	//Layout ����
	private BorderPane rootLayout;
	private AnchorPane bgLayout;
	
	//Controller ����
	private RootLayoutController rootCont;
	private Background bgCont;
	
	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	public static void main(String[] args) {
		launch(args);
	}
	
	public void initRootLayout() {
		try
		{//hello rrong nappayo
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
			rootLayout = (BorderPane) loader.load();
			
			Scene scene = new Scene(rootLayout);
			Stage stage = new Stage();
			stage.setScene(scene);
			
			stage.setTitle("������ Ÿ�̸�");
			
			
			stage.show();
		}
		catch(Exception e)
		{
			e.getStackTrace();
		}
	}
	
	public void initBackGround() {
		
	}
}
